#AmqpClientFactory

Creates a new AmqpClientFactory instance.

